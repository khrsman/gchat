<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class M_timeline extends CI_Model
{

    public function __construct()
    {
        parent::__construct(); //inherit dari parent
    }

    function get_user_timeline($user_id)
    {
        $this->db->select('id_user,id_timeline,caption,status,media_type,media,share,time_created');
        $this->db->where('id_user', $user_id);
        $query = $this->db->get('timeline');

       if ($query->num_rows() > 0) {
           $result = $query->result_array();
           return $result[0];
       } else {
           return FALSE;
       }
    }

    function get_friend_timeline($user_id)
    {
         $query = $this->db->query('SELECT id_user,id_timeline,caption,status,media_type,media,share,time_created '.
                        'FROM timeline '.
                        'where id_user in (select id_friends from contact where id_user = "'.$user_id.'") '.
                        'and timeline.share in ("PUBLIC","FRIENDS")');

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }

    function get_public_timeline()
    {
        $query = $this->db->query('SELECT id_user,id_timeline,caption,status,media_type,media,share,time_created '.
            'FROM timeline '.
            'where share = "PUBLIC"');

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }

    function get_timeline_comment()
    {
        $query = $this->db->query('SELECT id_comment,id_timeline,comment '.
            'FROM timeline_comment ');

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }


    function insert($data)
    {
        if($this->db->insert('timeline_comment', $data)){
            return 'Success';
        }else{
            $error = $this->db->error(); // Has keys 'code' and 'message'
            return  'Fail : '.$error['message'];
        }

    }


    function insert_comment($data)
    {
        if($this->db->insert('timeline_comment', $data)){
            return 'Success';
        }else{
            $error = $this->db->error(); // Has keys 'code' and 'message'
            return  'Fail : '.$error['message'];
        }

    }


}
