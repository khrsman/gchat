<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';

class registration extends REST_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_registration');
    }

    function empty_validator($input_name,$input){
        if (empty($input) || $input == ""){
            $this->response([
                'status' => FALSE,
                'message' => $input_name.' cannot be empty'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    function register_post(){

        $this->empty_validator('Username',$this->input->post('username'));
        $this->empty_validator('Password',$this->input->post('password'));
        $this->empty_validator('Email',$this->input->post('email'));

        $id_user = "8".time();
        $username = $this->input->post('username');
        $password = sha1(md5(strrev($this->input->post('password'))));
        $email = $this->input->post('email');
        $fullname = $this->input->post('fullname');
        $phone = $this->input->post('phone');
        $picture = $this->input->post('picture');

        $user_info = array(
            'id_user' 		=> $id_user,
            'username' 		=> $username,
            'password' 		=> $password,
            'email' 		=> $email,
            'full_name'     => $fullname,
            'phone' 		=> $phone,
            'picture' 		=> $picture,
            'last_seen' 	=> date("Y-m-d H:i:s"),
            'time_created' 	=> date("Y-m-d H:i:s"),
            'status_active'  => "Y",
            'service_time' 	=> date("Y-m-d H:i:s"),
            'service_action' => "insert",
            'service_user'	=> $id_user);

        $status = $this->m_registration->insert($user_info);

        $this->response([
            'status'    => TRUE,
            'message'   => $status,
            'data'      => $this->m_registration->get_user_detail($id_user)
        ], REST_Controller::HTTP_OK);
    }


}
