<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class M_registration extends CI_Model
{

    public function __construct()
    {
        parent::__construct(); //inherit dari parent
    }

    function get_user_detail($user_id)
    {
        $this->db->select('id_user,username,email,full_name,phone,picture,last_seen,status,time_created,status_active');
        $this->db->where('id_user', $user_id);
        $query = $this->db->get('user_info_gchat');
        $result = $query->result_array();

       if ($query->num_rows() > 0) {
           return $result[0];
       } else {
           return FALSE;
       }
    }

    function get_login_data($username)
    {
        $this->db->select('password,id_user');
        $this->db->where('username', $username);
        $query = $this->db->get('user_info_gchat');
        $result = $query->result_array();

        if ($query->num_rows() > 0) {
            return $result[0];
        } else {
            return FALSE;
        }
    }

    function insert($user_info)
    {
            if($this->db->insert('user_info_gchat', $user_info)){
               return 'Insert Success';
            }else{
                $error = $this->db->error(); // Has keys 'code' and 'message'
                return  'Insert Fail '.$error['message'];
            }

    }


}
