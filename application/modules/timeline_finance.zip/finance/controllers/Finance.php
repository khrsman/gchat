<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';

class Finance extends REST_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_finance');
       
    }

    function saldo_get(){
        $user_id = $this->get('id_user');
    	$saldo_tabungan = $this->m_finance->get_saldo_rekening_tabungan_anggota($user_id);
    	$saldo_virtual = $this->m_finance->get_saldo_rekening_virtual_anggota($user_id);
    	$saldo_loyalti = $this->m_finance->get_saldo_rekening_loyalti_anggota($user_id);

        $detail= array( 'tabungan' => $saldo_tabungan,
            'virtual' => $saldo_virtual,
            'loyalti' => $saldo_loyalti);

        if (empty($detail)) {
            $this->response([
                'status' => FALSE,
                'message' => 'Tidak ada saldo'
            ], REST_Controller::HTTP_NOT_FOUND);
        } else {
            $this->set_response($detail, REST_Controller::HTTP_OK);
        }
    }


    function transaction_history_get(){
        $user_id = $this->get('id_user');
        $history = $this->m_finance->get_history_transaksi($user_id);



        if (empty($history)) {
            $this->response([
                'status' => FALSE,
                'message' => 'There is no transaction'
            ], REST_Controller::HTTP_NOT_FOUND);
        } else {
            $this->set_response($history, REST_Controller::HTTP_OK);
        }
    }



    function empty_validator($input_name,$input){
        if (empty($input) || $input == ""){
            $this->response([
                'status' => FALSE,
                'message' => $input_name.' cannot be empty'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }


}
