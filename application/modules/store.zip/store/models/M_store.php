<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class M_store extends CI_Model
{

    public function __construct()
    {
        parent::__construct(); //inherit dari parent
    }

    function search_koperasi($keyword=NULL,$limit=NULL,$offset=NULL,$param_query=NULL)
    {
        $this->db->select('
                koperasi.id_koperasi as id_koperasi,
                koperasi.nama as nama_koperasi,
                ref_kelurahan.nama as nama_kelurahan,
                ref_kecamatan.nama as nama_kecamatan,
                ref_kabupaten.nama as nama_kabupaten,
                ref_provinsi.nama as nama_provinsi,
                koperasi_alamat.alamat as alamat_koperasi,
                koperasi_alamat.kode_pos as kode_pos
            ',
        FALSE
    );
        $this->db->from('koperasi');
        $this->db->join('koperasi_alamat','koperasi_alamat.id_koperasi=koperasi.id_koperasi','LEFT');
        $this->db->join('ref_kelurahan','koperasi_alamat.kelurahan=ref_kelurahan.id_kelurahan','LEFT');
        $this->db->join('ref_kecamatan','koperasi_alamat.kecamatan=ref_kecamatan.id_kecamatan','LEFT');
        $this->db->join('ref_kabupaten','koperasi_alamat.kabupaten=ref_kabupaten.id_kabupaten','LEFT');
        $this->db->join('ref_provinsi','ref_kabupaten.id_provinsi=ref_provinsi.id_provinsi','LEFT');

        $this->db->where('koperasi.status_active',1);

        if (!empty($param_query['filter_kabupaten'])) {
            if (is_array($param_query['filter_kabupaten'])) {
                foreach ($param_query['filter_kabupaten'] as $k => $v) {
                    $this->db->or_where('koperasi_alamat.kabupaten',$v['parameter']);
                }
            } else{
                $this->db->where('koperasi_alamat.kabupaten',$param_query['filter_kabupaten']);
            }

        }

        if (!empty($param_query['filter_kodepos'])) {
            if (is_array($param_query['filter_kodepos'])) {
                foreach ($param_query['filter_kodepos'] as $k => $v) {
                    $this->db->or_where('koperasi_alamat.kodepos',$v['parameter']);
                }
            } else{
                $this->db->where('koperasi_alamat.kode_pos',$param_query['filter_kodepos']);
            }
        }

       //  Keyword By
        if ($keyword!=NULL) {
            $this->db->like('koperasi.nama',$keyword);
        }

        $this->db->limit($limit,$offset);
        $query = $this->db->get();
//        echo $this->db->last_query();
//        die;
        //$result['data']     = $query->result_array();
        //$result['count']    = $query->num_rows();
        //$result['count_all']= $this->count_question_all();
        //$result['count_all']= $this->db->query('SELECT FOUND_ROWS() as count')->row()->count;


       if ($query->num_rows() > 0) {
           $result = $query->result_array();
           return $result;
       } else {
           return FALSE;
       }
    }

    function get_kategori_produk(){
            $this->db->select('id_kategori,urutan,nama');
            $this->db->from('produk_kategori');
            $this->db->order_by('produk_kategori.urutan','ASC');
            $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }


    function get_produk_koperasi($keyword=NULL,$limit=NULL,$offset=NULL,$param_query=NULL){
        $this->db->select('
            produk.id_produk as id_produk,
            produk.nama,
            produk_kategori.nama as nama_kategori,
            produk_foto.foto_path as foto_produk,
            produk.price_n as harga_pasar,
            produk.price_s as harga_member
        ');
        $this->db->from('produk');
        $this->db->join('produk_kategori_relation','produk.id_produk=produk_kategori_relation.id_produk','LEFT');
        $this->db->join('produk_kategori','produk_kategori_relation.id_kategori=produk_kategori.id_kategori','LEFT');
        $this->db->join('produk_foto','produk_foto.id_produk=produk.id_produk','LEFT');
        $this->db->join('user_info','produk.user=user_info.id_user','LEFT');
        $this->db->join('user_detail','produk.user=user_detail.id_user','LEFT');
        $this->db->join('produk_admin','produk.id_produk=produk_admin.id_produk','LEFT');
        $this->db->where('produk.status',1);

        // Filter
        /*if (!empty($param_query['filter_category'])) {
            if (is_array($param_query['filter_category'])) {
                foreach ($param_query['filter_category'] as $k => $v) {
                    $this->db->where('produk_kategori.id_kategori',$v['parameter']);
                }
            } else{
                $this->db->where('produk_kategori.id_kategori',$param_query['filter_category']);
            }

        }*/

        if (!empty($param_query['filter_produk_category'])) {
            if (is_array($param_query['filter_produk_category'])) {
                foreach ($param_query['filter_produk_category'] as $k => $v) {
                    $this->db->or_having('produk_kategori.id_kategori',$v['parameter']);
                }
            } else{
                $this->db->having('produk_kategori.id_kategori',$param_query['filter_produk_category']);
            }

        }

        if (!empty($param_query['filter_owner_produk'])) {
            if (is_array($param_query['filter_owner_produk'])) {
                foreach ($param_query['filter_owner_produk'] as $k => $v) {
                    $array_produk_owner[]=$v['parameter'];
                }
                $this->db->where_in('produk.owner',$array_produk_owner);
            } else{
                $this->db->where('produk.owner',$param_query['filter_owner_produk']);
            }

        }

        $this->db->where('user_info.koperasi',$param_query['filter_koperasi']);
        //$this->db->or_where('produk_admin.user_target',$param_query['filter_koperasi']);

        // Keyword By
        if ($keyword!=NULL) {
            $this->db->like('produk.nama',$keyword);
        }

        $this->db->limit($limit,$offset);
        // $this->db->order_by($param_query['sort'],$param_query['sort_order']);
        $this->db->order_by('produk_kategori.urutan','ASC');

        $query = $this->db->get();

        die($this->db->last_query());
//        $result['data']     = $query->result_array();
//        $result['count']    = $query->num_rows();
//        // $result['count_all']= $this->count_question_all();
//        $result['count_all']= $this->db->query('SELECT FOUND_ROWS() as count')->row()->count;

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }



    function get_produk_detail($produk_id){
        $this->db->select('produk.id_produk as id_produk,produk_kategori.nama as kategori_produk, produk.nama as nama_produk, desk as deskripsi, warna, tipe, berat, price_n as harga_pasar, price_s as harga_member, qty, terjual');
        $this->db->from('produk');
        $this->db->join('produk_kategori_relation','produk.id_produk=produk_kategori_relation.id_produk','LEFT');
        $this->db->join('produk_kategori','produk_kategori_relation.id_kategori=produk_kategori.id_kategori','LEFT');
        $this->db->join('produk_foto','produk_foto.id_produk=produk.id_produk','LEFT');
        $this->db->join('user_info','produk.user=user_info.id_user','LEFT');
        $this->db->where('produk.id_produk',$produk_id);
        $this->db->where('produk.status',1);
        $this->db->limit(1);

        $query = $this->db->get();

       // die($this->db->last_query());
        //$result['data']  = $query->result_array();
        //$result['count'] = $query->num_rows();

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }



    function get_cart($id_user)
    {
        $this->db->select('id_cart,id_user,id_produk,qty,price');
        $this->db->from('store_cart');
        $this->db->where('id_user',$id_user);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }

    function insert_cart($data)
    {
        if($this->db->insert('store_cart', $data)){
            return 'Success';
        }else{
            $error = $this->db->error(); // Has keys 'code' and 'message'
            return  'Fail : '.$error['message'];
        }

    }

    function update_cart($id_cart,$data)
    {
        $this->db->where('id_cart',$id_cart);
        if($this->db->update('store_cart', $data)){
            return 'Success';
        }else{
            $error = $this->db->error(); // Has keys 'code' and 'message'
            return  'Fail : '.$error['message'];
        }
    }

    function delete_cart($id_cart)
    {
        $this->db->where('id_cart',$id_cart);
        if($this->db->delete('store_cart')){
            return 'Success';
        }else{
            $error = $this->db->error(); // Has keys 'code' and 'message'
            return  'Fail : '.$error['message'];
        }
    }


    function insert_transaksi($data){
        $this->db->insert('transaksi', $data);
        return $this->db->affected_rows() > 0 ? TRUE : FALSE;
    }

    function insert_detail_batch($data){
        $this->db->insert_batch('detail_transaksi', $data);
        return $this->db->affected_rows() > 0 ? TRUE : FALSE;
    }

    function insert_pengiriman($data){
        $this->db->insert('transaksi_pengiriman', $data);
        return $this->db->affected_rows() > 0 ? TRUE : FALSE;
    }


    function update_batch($data){
        $this->db->update_batch('produk', $data, 'id_produk');
        return $this->db->affected_rows() > 0 ? TRUE : FALSE;
    }





}
