<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';

class Timeline extends REST_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_timeline');
    }

    function user_get(){
        $user_id = $this->get('id_user');
    	$user_timeline = $this->m_timeline->get_user_timeline($user_id);
        if (empty($user_timeline)) {
            $this->response([
                'status' => FALSE,
                'message' => 'No Status'
            ], REST_Controller::HTTP_NOT_FOUND);
        } else {
            $this->set_response($user_timeline, REST_Controller::HTTP_OK);
        }
    }

    function friend_get(){
        $user_id = $this->get('id_user');
        $friend_timeline = $this->m_timeline->get_friend_timeline($user_id);
        if (empty($friend_timeline)) {
            $this->response([
                'status' => FALSE,
                'message' => 'No Status'
            ], REST_Controller::HTTP_NOT_FOUND);
        } else {
            $this->set_response($friend_timeline, REST_Controller::HTTP_OK);
        }
    }

    function public_get(){
        $user_id = $this->get('id_user');
        $public_timeline = $this->m_timeline->get_public_timeline($user_id);
        if (empty($public_timeline)) {
            $this->response([
                'status' => FALSE,
                'message' => 'No Status'
            ], REST_Controller::HTTP_NOT_FOUND);
        } else {
            $this->set_response($public_timeline, REST_Controller::HTTP_OK);
        }
    }

    function empty_validator($input_name,$input){
        if (empty($input) || $input == ""){
            $this->response([
                'status' => FALSE,
                'message' => $input_name.' cannot be empty'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    function update_post(){
        $this->empty_validator('Status',$this->input->post('status'));
        $this->empty_validator('Caption',$this->input->post('caption'));

        $id_user = $this->input->post('id_user');
        $caption = $this->input->post('caption');
        $status = $this->input->post('status');
        $share = $this->input->post('share');
        $media_type = $this->input->post('media_type');
        $media_link = $this->input->post('media_link');

        $data = array(
            'id_user' 		=> $id_user,
            'status' 		=> $status,
            'caption' 		=> $caption,
            'share' 		=> $share,
            'media_type' 		=> $media_type,
            'media_link' 		=> $media_link,
            'time_created' 	=> date("Y-m-d H:i:s"),
            'service_action' => "INSERT");

        $status = $this->m_timeline->insert($data);

        $this->response([
            'status'    => TRUE,
            'message'   => $status,
            'data'      => $data
        ], REST_Controller::HTTP_OK);
    }

    




}
