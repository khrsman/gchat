<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model {

	public function __construct(){
		parent::__construct(); //inherit dari parent
	}
    
    function get($user_id){

    }

    function get_by_token($user_token){

    }

    function get_by_username($username){

    }

    function get_by_email($email){
        
    }

    function get_by_username_or_email($username_or_email){

    }

    function search($search_by,$keyword){

    }


    function insert($data){

    }

    function edit($data){
        
    }

    function remove($user_id){
        
    }

    


}
