<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';

class Profile extends REST_Controller {

    function __construct()
    {
        parent::__construct();

    }

    function me_get(){

    }


    function edit_put(){

    }
    

}
