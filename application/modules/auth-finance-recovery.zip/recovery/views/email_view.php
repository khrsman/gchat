<html><head>
   <title></title>
</head>
<body>
<div style="margin:0;padding:0" dir="ltr">
   <table cellspacing="0" cellpadding="0" style="border-collapse:collapse;width:98%" border="0">
      <tbody>
         <tr>
            <td style="font-family:'lucida grande',tahoma,verdana,arial,sans-serif;font-size:12px;padding:0px;background:#ffffff">
               <table cellspacing="0" cellpadding="0" width="100%" border="0" style="border-collapse:collapse;width:100%">
                  <tbody>
                     <tr>
                        <td style="font-size:11px;font-family:LucidaGrande,tahoma,verdana,arial,sans-serif;padding:0;background-color:#fff;border-left:none;border-right:none;border-top:none;border-bottom:none">
                           <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse">
                              <tbody>
                                 <tr>
                                    <td style="padding:0;width:100%"><span style="color:#ffffff;display:none!important;font-size:1px">Hi <?= $nama ?> , Kami mendapat permintaan untuk me-reset password anda.Jika anda mengabaikan email ini, password anda tidak akan berubah. Jika anda tidak melakukan ini, izinkan kami mengetahuinya .</span></td>
                                 </tr>
                                 <tr>
                                    <td style="padding:0;width:100%">
                                       <table cellspacing="0" cellpadding="0" width="100%" height="48px" bgcolor="#FFD604" style="border-collapse:collapse;width:100%">
                                          <tbody>
                                             <tr>
                                                <td>
                                                   <center>
                                                      <table cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                                         <tbody>
                                                            <tr>
                                                               <td align="left" style="width:100%;line-height:0px">
                                                                  <center>
                                                                     <table cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                                                        <tbody>
                                                                           <tr>
                                                                              <td><img src="&#10;                    http://smidumay.com/assets/compro/smi-logo.png                  " width="128" height="40" style="border:0" class="CToWUd"></td>
                                                                           </tr>
                                                                        </tbody>
                                                                     </table>
                                                                  </center>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                   </center>
                                                </td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </td>
                                 </tr>
                                 <tr>
                                    <td style="padding:0;width:100%">
                                       <table cellspacing="0" cellpadding="0" width="100%" bgcolor="#fff" style="border-collapse:collapse">
                                          <tbody>
                                             <tr>
                                                <td>
                                                   <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse">
                                                      <tbody>
                                                         <tr>
                                                            <td height="19">&nbsp;</td>
                                                         </tr>
                                                      </tbody>
                                                   </table>
                                                   <center>
                                                      <table cellspacing="0" cellpadding="0" width="480px" style="border-collapse:collapse;max-width:480px;width:auto">
                                                         <tbody>
                                                            <tr>
                                                               <td align="left" style="background-color:#ffffff;border-color:#c1c2c4;border-style:solid;display:block;border:none">
                                                                  <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse">
                                                                     <tbody>
                                                                        <tr>
                                                                           <td>
                                                                              <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse">
                                                                                 <tbody>
                                                                                    <tr>
                                                                                       <td height="24px" style="padding:20px 24px 0px 24px"><span style="font-size:22px;line-height:32px;font-weight:500;font-family:Helvetica Neue,Helvetica,Arial,sans-serif">Hi  <?= $nama ?>,</span></td>
                                                                                    </tr>
                                                                                 </tbody>
                                                                              </table>
                                                                              <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse">
                                                                                 <tbody>
                                                                                    <tr>
                                                                                       <td height="20px" style="padding:16px 24px 0px 24px"><span style="font-size:16px;line-height:20px;font-family:Helvetica Neue,Helvetica,Arial,sans-serif">Kami mendapat permintaan untuk me-reset password anda.</span></td>
                                                                                    </tr>
                                                                                 </tbody>
                                                                              </table>
                                                                              <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse">
                                                                                 <tbody>
                                                                                    <tr>
                                                                                       <td height="17px" style="padding:30px 0px 30px 0px">
                                                                                          <center><a style="color:#2b5a83;text-decoration:none;border-radius:3px;border:1px solid #2b5a83;padding:10px 19px 12px 19px;font-size:17px;font-weight:500;white-space:nowrap;border-collapse:collapse;display:inline-block;font-family:Helvetica Neue,Helvetica,Arial,sans-serif" href="<?= $link ?>">Reset Password</a></center>
                                                                                       </td>
                                                                                    </tr>
                                                                                 </tbody>
                                                                              </table>
                                                                              <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse">
                                                                                 <tbody>
                                                                                    <tr>
                                                                                       <td height="20px" style="padding:0px 24px 0px 24px"><span style="font-size:16px;line-height:20px;font-family:Helvetica Neue,Helvetica,Arial,sans-serif">Jika anda mengabaikan email ini, password anda tidak akan berubah. </span><a href="#" style="color:#3b5998;text-decoration:none" > </a></td>
                                                                                    </tr>
                                                                                 </tbody>
                                                                              </table>
                                                                              <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse">
                                                                                 <tbody>
                                                                                    <tr>
                                                                                       <td height="20px" style="padding:16px 24px 38px 24px"><span style="font-size:16px;line-height:20px;font-family:Helvetica Neue,Helvetica,Arial,sans-serif">Jika anda tidak meminta reset password,<a href="#" style="color:#3b5998;text-decoration:underline"></a>izinkan kami mengetahuinya .</span></td>
                                                                                    </tr>
                                                                                 </tbody>
                                                                              </table>
                                                                           </td>
                                                                        </tr>
                                                                     </tbody>
                                                                  </table>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                   </center>
                                                </td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </td>
                                 </tr>
                                 <tr>
                                    <td style="padding:0;width:100%">
                                       <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse;width:100%">
                                          <tbody>
                                             <tr>
                                                <td>
                                                   <center>
                                                      <table cellspacing="0" cellpadding="0" width="100%" style="border-collapse:collapse">
                                                         <tbody>
                                                            <tr>
                                                               <td>
                                                                  <table cellspacing="0" cellpadding="0" width="100%" border="0" style="border-collapse:collapse">
                                                                     <tbody>
                                                                        <tr>
                                                                           <td style="font-size:12px;font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;padding:24px 0px 24px 0px;border-left:none;border-right:none;border-top:solid 1px #c9cbcd;border-bottom:none;color:#ffffff;font-weight:300;line-height:20px;text-align:center; background-image:radial-gradient(circle farthest-side at center bottom,#1bbc9b,#07614f 125%)">Kontak kami <a href="http://smidumay.com/contact" style="color:#ffffff;text-decoration:underline;font-family:Helvetica Neue,Helvetica,Lucida Grande,tahoma,verdana,arial,sans-serif;font-weight:bold" target="_blank">disini </a></td>
                                                                        </tr>
                                                                     </tbody>
                                                                  </table>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                   </center>
                                                </td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </td>
                                 </tr>
                              </tbody>
                           </table>
                        </td>
                     </tr>
                  </tbody>
               </table>
               <span style="width:100%"><img src="https://ci3.googleusercontent.com/proxy/t2f3qpQAd3oPyhmzoVExvTzSajPlL4E-3IU5AwJ3M5Pjpu0ZkT_7ONdtemyp0SE4eGcv4Y5xjVgDMWmnJzrrp3XK6bFxq9EpG7wyXomCWFbLVesDHvMoSohXcFXS2IR4VthCB5xl5ObTkCp7hExMUR1e5Nnlnpse_FHp=s0-d-e1-ft#https://www.facebook.com/email_open_log_pic.php?mid=HMjI1Mzg3NDU1OnJpemt5dGFoaXI5NkBnbWFpbC5jb206NTg0" style="border:0;width:1px;min-height:1px" class="CToWUd"></span>
            </td>
         </tr>
      </tbody>
   </table>
</div>

</body></html>