<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';

class Gerai extends REST_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_gerai');
        $this->load->library('core_banking_api');
    }


    function empty_validator($input_name,$input){
        if (empty($input) || $input == ""){
            $this->response([
                'status' => FALSE,
                'message' => $input_name.' cannot be empty'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    function topup_get(){

           // $data['form_action'] = site_url().'gerai/pulsa/topup/'.$this->uri->segment(4);

        $url = 'http://localhost/gchat_web_api/assets/provider/';
        
        $provider = $this->get('provider');


            switch ($provider) {

                case 'indosat':

                    $data['operator_id']	= 'INDOSAT';
                    $data['products']		=  $this->get_product($data['operator_id']);
                    $data['provider_logo'] 	= $url.'/'.'indosat.png';
                    $data['provider_name'] 	= 'Indosat';

                    break;

                case 'telkomsel':

                    $data['operator_id']	= 'TELKOMSEL';
                    $data['products']		=  $this->get_product($data['operator_id']);
                    $data['provider_logo'] 	= $url.'/'.'telkomsel.png';
                    $data['provider_name'] 	= 'Telkomsel';

                    break;

                case 'xl':

                    $data['operator_id']	= 'XL';
                    $data['products']		=  $this->get_product($data['operator_id']);
                    $data['provider_logo'] 	= $url.'/'.'XL.png';
                    $data['provider_name'] 	= 'XL';

                    break;

                case 'esia':

                    $data['operator_id']	= 'ESIA';
                    $data['products']		=  $this->get_product($data['operator_id']);
                    $data['provider_logo'] 	= $url.'/'.'esia.png';
                    $data['provider_name'] 	= 'Esia';

                    break;

                case 'smartfren':

                    $data['operator_id']	= 'SMARTFREN';
                    $data['products']		=  $this->get_product($data['operator_id']);
                    $data['provider_logo'] 	= $url.'/'.'smartfren.png';
                    $data['provider_name'] 	= 'Smartfren';

                    break;

                case 'flexi':

                    $data['operator_id']	= 'FLEXI';
                    $data['products']		=  $this->get_product($data['operator_id']);
                    $data['provider_logo'] 	= $url.'/'.'flexi.png';
                    $data['provider_name'] 	= 'Flexi';

                    break;

                case 'axis':

                    $data['operator_id']	= 'AXIS';
                    $data['products']		=  $this->get_product($data['operator_id']);
                    $data['provider_logo'] 	= $url.'/'.'axis.png';
                    $data['provider_name'] 	= 'Axis';

                    break;

                case 'tri':

                    $data['operator_id']	= 'THREE';
                    $data['products']		=  $this->get_product($data['operator_id']);
                    $data['provider_logo'] 	= $url.'/'.'3.png';
                    $data['provider_name'] 	= 'Tri';


                    break;

                case 'ceria':

                    $data['operator_id']	= 'CERIA';
                    $data['products']		= $this->get_product($data['operator_id']);
                    $data['provider_logo'] 	= $url.'/'.'3.png';
                    $data['provider_name'] 	= 'Ceria';

                    break;

                default:

                    redirect('gerai/pulsa');

                    /*$data['page'] = "under_404";
                    $this->load->view('main_view',$data);*/

                    break;

            }

        $this->response([
            'status' => TRUE,
            'message' =>'Success',
            'data' => $data
        ], REST_Controller::HTTP_OK);

    }

    function get_product($operator_id,$nominal=NULL){
        $parameter_produk	= array(
            'kode_operator'			=> $operator_id,
            'kode_kategori_produk' 	=> 'PULSA',
            'jenis_transaksi' 		=> 'BELI',
        );
        if ($nominal!=NULL) {
            $parameter_produk['nominal_produk'] = $nominal;
        }
        $get_product = $this->m_gerai->get_nominal($parameter_produk);
        return $get_product;
    }


    function is_pin_valid(){
        $id_user = $this->session->userdata('id_user');
        $pin 	 = $this->input->post('pin');

        $permission = $this->core_banking_api->check_pin($id_user,$pin);

        if ($permission['status']==TRUE) {
            return TRUE;
        }else{
            $this->form_validation->set_message('is_pin_valid', $permission['message']);
            return FALSE;
        }
    }


    function is_product_valid(){
        $operator_id = $this->input->post('operator_id');
        $nominal 	 = $this->input->post('nominal');
        $get_product = $this->get_product($operator_id,$nominal);

        if ($get_product==FALSE) {
            $this->form_validation->set_message('is_product_valid', 'Maaf Produk Tidak Ditemukan');
            return FALSE;
        }

        $id_user = $this->session->userdata('id_user');
        $total_debit = $get_product[0]['harga_gerai'];

        $permission = $this->core_banking_api->debit_virtual_account_permission($id_user,$total_debit);

        if ($permission['status']==TRUE) {
            return TRUE;
        }else{
            $this->form_validation->set_message('is_product_valid', 'Transaksi Tidak Diizinkan Karena '.$permission['message']);
            return FALSE;
        }

    }

    function topup_confirm_post(){



        $id_user = $this->post('id_user');
        $pin = $this->post('pin');
        $provider_name = $this->post('provider_name');
        $provider_logo = $this->post('provider_logo');
        $phone_number = $this->post('phone_number');
        $operator_id = $this->post('operator_id');
        $nominal = $this->post('nominal');


        $this->empty_validator('ID user',$id_user);
        $this->empty_validator('pin',$pin);
        $this->empty_validator('Provider Name',$provider_name);
        $this->empty_validator('Provider Logo',$provider_logo);
        $this->empty_validator('Phone Number',$phone_number);
        $this->empty_validator('Operator ID',$operator_id);
        $this->empty_validator('Nominal',$nominal);

            $post = $this->input->post();

            $get_product = $this->get_product($operator_id,$nominal);
            if ($get_product==FALSE) {
                $this->response([
                    'status' => false,
                    'message' =>'Product not found',
                    'data' => NULL
                ], REST_Controller::HTTP_BAD_REQUEST);

            }else{
                $get_product = $get_product[0];
            }

            if ($nominal!=$get_product['nominal_produk']) {
                $this->response([
                    'status' => false,
                    'message' =>'Nominal not match',
                    'data' => NULL
                ], REST_Controller::HTTP_BAD_REQUEST);
            }

            $service_user 	= $id_user;
            $service_action = 'INSERT_MOBILE';
            $trasaction_id 	= '13'.time();

            $data_insert = array(
                'no_transaksi' 			=> $trasaction_id,
                'kode_vendor' 			=> $get_product['kode_vendor'],
                'kode_operator' 		=> $get_product['kode_operator'],
                'kode_produk' 			=> $get_product['kode_produk'],
                'kode_kategori_produk' 	=> $get_product['kode_kategori_produk'],
                'nama_produk' 			=> $get_product['nama_produk'],
                'nominal_produk' 		=> $get_product['nominal_produk'],
                'harga_vendor'			=> $get_product['harga_vendor'],
                'harga_gerai'			=> $get_product['harga_gerai'],
                'jenis_transaksi'		=> 'BELI',
                'id_user'				=> $service_user,
                'msisdn'				=> $phone_number,
                'tanggal_transaksi'		=> date('Y-m-d H:i:s'),
                'tanggal'			=> date('d'),
                'bulan'				=> date('m'),
                'tahun'				=> date('Y'),
                'service_time'			=> date('Y-m-d H:i:s'),
                'service_user'			=> $service_user,
                'service_action'		=> $service_action
            );



            $this->load->library('vsi_api');

            $data = array(
                'service_user' 	=> $service_user,
                'produk'   		=> $get_product['kode_produk'],
                'tujuan'    	=> $post['phone_number'],
                'memberreff' 	=> $trasaction_id,
            );

            $data_report['provider_name'] 	= $post['provider_name'];
            $data_report['provider_logo'] 	= $post['provider_logo'];
            $data_report['product'] 		= $get_product;
            $data_report['data_insert'] 	= $data_insert;

            $permission = $this->core_banking_api->debit_virtual_account_permission($service_user,$get_product['harga_gerai']);

            if ($permission['status']==FALSE) {
                $this->response([
                    'status' => false,
                    'message' =>'Failed: '.$permission['message'],
                    'data' => NULL
                ], REST_Controller::HTTP_BAD_REQUEST);
            }

            // REQUEST KE VSI
            $request_charge = $this->vsi_api->charge($data);



            if ($request_charge==FALSE) {
                $data_insert['keterangan']  = 'Internal Server Error. API Error';
                $insert = $this->m_gerai->insert_transaksi_gerai($data_insert);
                $this->response([
                    'status' => false,
                    'message' =>'Failed: Transaksi Gagal.Maaf, Internal Server sedang ada gangguan.',
                    'data' => NULL
                ], REST_Controller::HTTP_BAD_REQUEST);

            }elseif ($request_charge['status']==FALSE) {

                $data_insert['ref_trxid']   = $request_charge['message']['trxid'];
                $data_insert['status'] 		= 'GAGAL';
                $data_insert['keterangan']  = $request_charge['message']['response_message'];
                $insert = $this->m_gerai->insert_transaksi_gerai($data_insert);
                $this->response([
                    'status' => false,
                    'message' =>'Failed: '.$request_charge['message']['response_message'],
                    'data' => NULL
                ], REST_Controller::HTTP_BAD_REQUEST);

            }else{

                //JUST FOR TEST
                /*print_r('<pre>');
                print_r($request_charge);
                print_r('</pre>');*/

                $data_insert['ref_trxid']   = $request_charge['message']['trxid'];
                $data_insert['status'] 		= 'SUKSES';
                $data_insert['keterangan']  = $request_charge['message']['response_message'];
                $insert = $this->m_gerai->insert_transaksi_gerai($data_insert);

                $this->load->library('core_banking_api');
                $total_debit 		= $get_product['harga_gerai'];
                $kode_transaksi 	= 'GERAI';
                $jenis_transaksi 	= 'TOPUP PULSA '.$get_product['nama_produk'];
                $debet_virtual_account = $this->core_banking_api->debit_virtual_account($id_user,$total_debit,$kode_transaksi,$jenis_transaksi,$trasaction_id);

                // REQUEST KE DATACELL BERHASIL. DEBET VIRTUAL ACCOUNT
                if ($debet_virtual_account['status']!=FALSE) {
                    $total_point 		= $get_product['harga_gerai']-$get_product['harga_vendor'];
                    $sumber_dana 		= 'GERAI';

                    // DEBET VIRTUAL ACCOUNT BERHASIL. DEPOSIT POINT LOYALTI
                    $share_profit = $this->core_banking_api->share_profit($id_user,$total_point,$sumber_dana,$jenis_transaksi,$trasaction_id);

                    if ($share_profit['status']!=FALSE) {

                        // DEPOSTI LOYALTI BERHASIL. INSERT TRANSAKSI GERAI
                        /*$data_insert['ref_trxid']   = $request_charge['message']['trxid'];
                        $data_insert['status'] 		= 'SUKSES';
                        $data_insert['keterangan']  = $request_charge['message']['response_message'];
                        $insert = $this->gerai_transaksi_model->insert($data_insert);*/

                        if ($insert!=FALSE) {
                            // INSERT TRANSAKSI GERAI BERHASIL

                            $this->response([
                                'status' => true,
                                'message' =>'Topup Success'
                            ], REST_Controller::HTTP_OK);

                        } else {
                            $this->response([
                                'status' => false,
                                'message' =>'Topup Gagal'
                            ], REST_Controller::HTTP_BAD_REQUEST);
                        }

                    }   else{

                        $this->response([
                            'status' => false,
                            'message' => "Isi Pulsa Berhasil (Not Sharing Profit Payment). ".$debet_virtual_account['message']
                        ], REST_Controller::HTTP_BAD_REQUEST);
                    }


                }else{
                    $this->response([
                        'status' => false,
                        'message' => "Isi Pulsa Berhasil (Debet Failed) ".$debet_virtual_account['message']
                    ], REST_Controller::HTTP_BAD_REQUEST);
                }


            }

    }


    function topup_report(){

        if (!$this->session->has_userdata('report')) {
            redirect('gerai/pulsa');
        }

        $report =  $this->session->userdata('report');
        $this->session->unset_userdata('report');

        $data['report'] = $report;

        $data['page'] 		 = "pulsa/pulsa_topup_report_form_view";
        $this->load->view('main_view',$data);

    }





}
