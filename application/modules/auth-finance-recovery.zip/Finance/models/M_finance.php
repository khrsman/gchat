<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class M_finance extends CI_Model
{

    public function __construct()
    {
        parent::__construct(); //inherit dari parent
        $this->db_web_app = $this->load->database('db_smidumay',TRUE);
    }

    function get_saldo_rekening_tabungan_anggota($user_id){
        $this->db_web_app->select('no_rekening no_rekening,saldo');
        $this->db_web_app->where('id_user', $user_id);
        $query = $this->db_web_app->get('mcb_rekening_tabungan');

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }

    function get_saldo_rekening_virtual_anggota($user_id){
        $this->db_web_app->select('no_rekening_virtual no_rekening,saldo');
        $this->db_web_app->where('id_user', $user_id);
        $query = $this->db_web_app->get('mcb_rekening_virtual');

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }
    function get_saldo_rekening_loyalti_anggota($user_id){
        $this->db_web_app->select('no_rekening_loyalti no_rekening,saldo');
        $this->db_web_app->where('id_user', $user_id);
        $query = $this->db_web_app->get('mcb_rekening_loyalti');

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return $result;
        } else {
            return FALSE;
        }
    }


    function get_user_timeline($user_id)
    {
        $this->db->select('id_user,id_timeline,caption,status,media_type,media,share,time_created');
        $this->db->where('id_user', $user_id);
        $query = $this->db->get('timeline');

       if ($query->num_rows() > 0) {
           $result = $query->result_array();
           return $result[0];
       } else {
           return FALSE;
       }
    }






}
