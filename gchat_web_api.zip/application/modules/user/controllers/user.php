<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';

class user extends REST_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_user');
    }

    function detail_get()
    {
        $user_id = $this->get('id_user');
        $user = $this->m_user->get_user_detail($user_id);

        if (empty($user)) {
            $this->response([
                'status' => FALSE,
                'message' => 'User not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        } else {
            $this->set_response($user, REST_Controller::HTTP_OK);
        }
    }

    function update_picture_post(){

            $this->empty_validator('Picture',$this->input->post('picture'));

            $id_user = $this->input->post('id_user');
            $picture = $this->input->post('picture');

            $data = array(
                'picture' 		=> $picture,
                'service_time' 	=> date("Y-m-d H:i:s"),
                'service_action' => "UPDATE");

            $this->m_user->set_picture($data,$id_user);

            $this->response([
                'status'    => TRUE,
                'message'   => 'Profile picture has been updated',
                'data'      => $this->m_user->get_user_detail($id_user)
            ], REST_Controller::HTTP_OK);

    }


    function update_name_post(){

        $this->empty_validator('Name',$this->input->post('name'));

        $id_user = $this->input->post('id_user');
        $name = $this->input->post('name');

        $data = array(
            'full_name' 		=> $name,
            'service_time' 	=> date("Y-m-d H:i:s"),
            'service_action' => "UPDATE");

        $this->m_user->set_name($data,$id_user);

        $this->response([
            'status'    => TRUE,
            'message'   => 'Name has been updated',
            'data'      => $this->m_user->get_user_detail($id_user)
        ], REST_Controller::HTTP_OK);

    }

    function update_status_post(){

        $this->empty_validator('Status',$this->input->post('status'));

        $id_user = $this->input->post('id_user');
        $status = $this->input->post('status');

        $data = array(
            'status' 		=> $status,
            'service_time' 	=> date("Y-m-d H:i:s"),
            'service_action' => "UPDATE");

        $this->m_user->set_name($data,$id_user);

        $this->response([
            'status'    => TRUE,
            'message'   => 'Status has been updated',
            'data'      => $this->m_user->get_user_detail($id_user)
        ], REST_Controller::HTTP_OK);

    }


    function empty_validator($input_name,$input){
        if (empty($input) || $input == ""){
            $this->response([
                'status' => FALSE,
                'message' => $input_name.' cannot be empty'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }



}
